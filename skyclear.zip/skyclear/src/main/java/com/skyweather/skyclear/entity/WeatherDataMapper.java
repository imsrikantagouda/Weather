package com.skyweather.skyclear.entity;

import com.fasterxml.jackson.databind.ObjectMapper;

public class WeatherDataMapper {
    private static final ObjectMapper objectMapper = new ObjectMapper();

    public static WeatherData mapResponseToWeatherData(String jsonResponse) throws Exception {
        return objectMapper.readValue(jsonResponse, WeatherData.class);
    }
}
