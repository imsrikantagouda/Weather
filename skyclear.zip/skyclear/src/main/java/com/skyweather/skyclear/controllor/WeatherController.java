package com.skyweather.skyclear.controllor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.skyweather.skyclear.entity.WeatherData;
import com.skyweather.skyclear.service.WeatherService;
import com.skyweather.skyclear.service.WeatherServiceException;

@RestController
public class WeatherController {

	@Autowired
	private WeatherService weatherService;
	
	  @CrossOrigin(origins = "http://localhost:4200", methods = {RequestMethod.GET, RequestMethod.OPTIONS})
	@RequestMapping(value = "/weather/{location}", method = RequestMethod.GET)
	public ResponseEntity<?> getWeather(@RequestParam(name="location", required = false, defaultValue = "mumbai") String location) {
		try {
			WeatherData weatherData = weatherService.getWeatherData(location);
			return ResponseEntity.ok(weatherData);
		} catch (WeatherServiceException e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
		}
	}

}